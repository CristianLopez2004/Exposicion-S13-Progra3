import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Ventana extends JFrame {

    private PanelGrafico panelGrafico;

    private JPanel contentPane;
    private JLabel labelEstado;
    private JLabel labelConexiones;
    private JButton btnSiguiente;

    private int estado = 0;

    public Ventana() {
        setTitle("Red de Comunicación Dinámica");
        setContentPane(contentPane); // Asegúrate que el nombre esté correcto
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
        panelGrafico = new PanelGrafico();
        getContentPane().add(panelGrafico, BorderLayout.SOUTH);

        actualizarEstado();

        btnSiguiente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                estado = (estado + 1) % 4;
                actualizarEstado();
            }
        });
    }

    private void actualizarEstado() {
        List<int[]> conexiones = new ArrayList<>();

        switch (estado) {
            case 0:
                labelEstado.setText("Estado: G1");
                labelConexiones.setText("Conexión: A - B");
                conexiones.add(new int[]{0, 1});
                break;
            case 1:
                labelEstado.setText("Estado: G2");
                labelConexiones.setText("Conexión: B - C");
                conexiones.add(new int[]{1, 2});
                break;
            case 2:
                labelEstado.setText("Estado: G3");
                labelConexiones.setText("Conexión: C - D");
                conexiones.add(new int[]{2, 3});
                break;
            case 3:
                labelEstado.setText("Estado: G4");
                labelConexiones.setText("Conexión: A - D");
                conexiones.add(new int[]{0, 3});
                break;
        }

        panelGrafico.setConexiones(conexiones);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().contentPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}


