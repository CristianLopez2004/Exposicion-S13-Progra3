import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PanelGrafico extends JPanel {

    private List<int[]> conexiones = new ArrayList<>();

    public PanelGrafico() {
        setPreferredSize(new Dimension(400, 250));
        setBackground(Color.WHITE);
    }

    public void setConexiones(List<int[]> nuevasConexiones) {
        this.conexiones = nuevasConexiones;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // Posiciones fijas de nodos
        int[][] posiciones = {
                {80, 180},   // A
                {180, 50},   // B
                {280, 180},  // C
                {180, 250}   // D
        };

        // Dibujar nodos
        String[] nombres = {"A", "B", "C", "D"};
        g2.setColor(Color.BLACK);
        for (int i = 0; i < posiciones.length; i++) {
            int x = posiciones[i][0];
            int y = posiciones[i][1];
            g2.fillOval(x - 15, y - 15, 30, 30);
            g2.drawString(nombres[i], x - 5, y + 5);
        }

        // Dibujar conexiones
        g2.setStroke(new BasicStroke(2));
        g2.setColor(Color.BLUE);
        for (int[] c : conexiones) {
            int x1 = posiciones[c[0]][0];
            int y1 = posiciones[c[0]][1];
            int x2 = posiciones[c[1]][0];
            int y2 = posiciones[c[1]][1];
            g2.drawLine(x1, y1, x2, y2);
        }
    }
}
